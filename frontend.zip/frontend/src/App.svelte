

<script>
	export let name;
	import {onMount} from "svelte";

	let messageInput;
	let messages = [];
	let message = '';
	let inputText = "";
	let statusLog = "";
	let name_set = 0;
	let userName = "";
	let data = {};

	//foco pra variável messageInput (|piscando)
	onMount(() => {
		messageInput.focus();
	});
	const ws = new WebSocket("ws://localhost:8765");

	ws.onopen = function(e){
		console.log("WebSocket client Connected");
		message = "Welcome! Please type: @name 'YourName'"; 
		messages = [...messages, message];	
	}

	ws.onmessage = function(e) {
		data = JSON.parse(e.data);
		if (data.action == "acceptName") {
			name_set = 1;
			userName = data.content
			statusLog = userName + " is logged in!"
			message = "Hello " + userName + ", let's chat! Shall we?"; 
			messages = [...messages, message];	
		}
		else if (data.action == "retryName") {
			message = "Please try again, either you chose a name already in use or you typed the wrong pattern! [Remember: @name 'YourName']"; 
			messages = [...messages, message];			
		}
		else if (data.action == "pvtMessage") {
			message = "Private from (" + data.sender +") >> " + data.content; 
			messages = [...messages, message];			
		}
		else if (data.action == "publicMessage") {
			message = "Public from (" + data.sender +") >> " + data.content; 
			messages = [...messages, message];			
		}
		else if (data.action == "newUser") {
			message = data.sender +" joined this room"; 
			messages = [...messages, message];			
		}
		else {
			console.log("Invalid Message");		
		}
	}

	function handleClick(){
		let output;
		if (name_set == 0){
			output = {"action": "tryName", "content": inputText};
		}
		else if (inputText.charAt(0) == "@") {
			let receiver = inputText.split(" ")[0].substring(1);
			let msg = inputText.substr(inputText.indexOf(" ") + 1);
			console.log(receiver);	
			console.log(msg);	
			output = {"action": "pvtMessage", "sender":userName, "receiver": receiver, "content": msg};
			message = "You (" + receiver +") >> " + msg; 
			messages = [...messages, message];
		} 
		else {
			output = {"action": "publicMessage", "sender":userName, "receiver": "all", "content": inputText};
			message = "You (all) " + inputText;
			messages = [...messages, message];
		}
		ws.send(JSON.stringify(output));
		inputText = "";
	}
</script>

<main>
	<h1>{name}!</h1>
	<h2>{statusLog}</h2>
	<p>
		Welcome! To try private mode use: @"Your Friend" at the beggining of the message.
	</p>
	<div class="chatbox">
		{#each messages as message}
			<p>{message}</p>
		{/each}	
	</div>
	<form class="inputbox">
		<input type="text" bind:this={messageInput} bind:value={inputText}/>
		<button type="submit" on:click|preventDefault={handleClick}>Send</button>
	</form>

</main>

<style>
	* {
	box-sizing: border-box;
	}
	main {
		width: calc(100% - 30px);
		text-align: center;
		padding: 1em;
		max-width: 1240px;
		margin: 0 auto;
	}
	h1 {
		color: #ff3e00;
		text-transform: uppercase;
		font-size: 4em;
		font-weight: 100;
	}

	h2 {
		display: block;
		color: #000000;
		font-size: 1em;
		font-weight: 100;
		height: 100;
	}

	.chatbox {
		width: 100%;
		height: 50vh;
		padding: 0 1cm;
		text-align: left;
		background-color: #eee;
		overflow-y: scroll;
		overscroll-behavior-y: contain;
		scroll-snap-type: y proximity;
	}
	.chatbox p{
		margin-top: 0.5cm;
		margin-bottom: 0;
		padding-bottom: 0.5cm;
	}
	.chatbox > p:last-child{
		scroll-snap-align: end;
	}
	.inputbox{
		display: flex;
		margin-top: 0.5cm;
	}
	.inputbox input{
		flex-grow: 1;
	}
</style>